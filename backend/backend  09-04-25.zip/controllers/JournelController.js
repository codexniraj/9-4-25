// controllers/JournelController.js
const pool = require('../config/db');

exports.uploadJournal = async (req, res) => { 
  try {
    const { email, company, data, withItems, uploadedFileName } = req.body;
    if (!email || !company || !data) {
      return res.status(400).json({ error: 'Missing data' });
    }
    
    // Create a unique safe table name for the journal upload
    const safeTable = `journal_temp_${email.toLowerCase().replace(/[@.]/g, '_')}_${Date.now()}`;
    const columns = withItems ? `
      journal_no NUMERIC, reference_no NUMERIC, date DATE, cost_center TEXT, particulars TEXT,
      name_of_item TEXT, quantity NUMERIC, rate NUMERIC, dr_cr TEXT, amount NUMERIC,
      ledger_narration TEXT, narration TEXT
    ` : `
      journal_no NUMERIC, reference_no NUMERIC, date DATE, cost_center TEXT, particulars TEXT,
      dr_cr TEXT, amount NUMERIC, ledger_narration TEXT, narration TEXT
    `;
    
    // Create a temporary table for the journal upload
    await pool.query(`CREATE TABLE ${safeTable} (id SERIAL PRIMARY KEY,${columns});`);
    
    // Fetch valid ledger descriptions for the company
    const ledgerRes = await pool.query('SELECT description FROM ledgers WHERE company_id = $1', [company]);
    const ledgerNames = ledgerRes.rows.map(r => r.description.toLowerCase().trim());
    const invalidLedgers = new Set();
    const referenceMap = {}; // Map to store reference data: refNo => { journal_no, date }
    
    // Process each row from the provided data
    for (const [index, row] of data.entries()) {
      const requiredFields = withItems
        ? ["Reference No", "Date", "Particulars", "Name Of Item", "Quantity", "Rate", "Dr/Cr", "Amount"]
        : ["Reference No", "Date", "Particulars", "Dr/Cr", "Amount"];

      for (const field of requiredFields) {
        if (!row[field]) {
          return res.status(400).json({ error: `Missing field "${field}" in row ${index + 1}` });
        }
      }
      
      // Format the date from the row into ISO format
      const rawDate = row["Date"];
      let formattedDate = null;
      try {
        if (typeof rawDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(rawDate)) {
          // Already in ISO format
          formattedDate = rawDate;
        } else if (typeof rawDate === "string" && rawDate.includes("-")) {
          // Assuming DD-MM-YYYY or similar
          const [dd, mm, yyyy] = rawDate.split("-");
          formattedDate = `${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
        } else if (typeof rawDate === "string" && rawDate.includes("/")) {
          // Assuming DD/MM/YYYY
          const [dd, mm, yyyy] = rawDate.split("/");
          formattedDate = `${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
        } else if (typeof rawDate === "number") {
          // Convert Excel serial date to ISO format
          const jsDate = new Date((rawDate - 25569) * 86400 * 1000);
          formattedDate = `${jsDate.getFullYear()}-${String(jsDate.getMonth() + 1).padStart(2, '0')}-${String(jsDate.getDate() -  1).padStart(2, '0')}`;
        }
      } catch (e) {
        console.error("Invalid date format:", rawDate);
        formattedDate = null;
      }
      
      const refNo = row["Reference No"];
      let journalNo = row["Journal No"];
      if (!referenceMap[refNo]) {
        referenceMap[refNo] = {
          journal_no: journalNo,
          date: formattedDate
        };
      } else {
        journalNo = referenceMap[refNo].journal_no;
      }
      
      // Validate ledger name
      const ledgerName = row["Particulars"]?.toLowerCase().trim();
      if (!ledgerNames.includes(ledgerName)) {
        invalidLedgers.add(row["Particulars"]);
      }
      
      // Prepare values and placeholders for insertion
      const values = withItems ? [
        journalNo, refNo, referenceMap[refNo].date, row["Cost center"] || null, row["Particulars"],
        row["Name Of Item"], row["Quantity"], row["Rate"], row["Dr/Cr"], row["Amount"],
        row["Ledger Narration"] || null, row["Narration"] || null
      ] : [
        journalNo, refNo, referenceMap[refNo].date, row["Cost center"] || null, row["Particulars"],
        row["Dr/Cr"], row["Amount"], row["Ledger Narration"] || null, row["Narration"] || null
      ];

      const placeholders = values.map((_, i) => `$${i + 1}`).join(', ');
      const insertColumns = withItems
      ? `(journal_no, reference_no, date, cost_center, particulars, name_of_item, quantity, rate, dr_cr, amount, ledger_narration, narration)`
      : `(journal_no, reference_no, date, cost_center, particulars, dr_cr, amount, ledger_narration, narration)`;
      await pool.query(`INSERT INTO ${safeTable} ${insertColumns} VALUES (${placeholders})`, values);
    }
    
    // Insert a record into the persistent table to track this journal upload
    await pool.query(`
      INSERT INTO user_journal_temp_tables (email, company, temp_table, uploaded_file)
      VALUES ($1, $2, $3, $4)
    `, [email, company, safeTable, uploadedFileName || safeTable]);

    res.json({
      message: "Journal uploaded and stored temporarily",
      table: safeTable,
      invalidLedgers: Array.from(invalidLedgers)
    });
  } catch (err) {
    console.error('Error uploading journal:', err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.getJournalData = async (req, res) => {
  try {
    const { tempTable } = req.query;
    if (!tempTable) {
      return res.status(400).json({ error: 'Temp table name required' });
    }
    
    const result = await pool.query(`SELECT * FROM ${tempTable}`);
    console.log("✅ Fetched data from DB:", result.rows);  // very clear log
    res.json(result.rows);
  } catch (err) {
    console.error('❌ Error fetching journal data:', err);
    res.status(500).json({ error: 'Database error', details: err.message });
  }
};




exports.updateJournalRow = async (req, res) => {
  console.log("✅ /api/updateJournalRow hit!");

  try {
    const { tempTable, updatedRow } = req.body;
    const rowId = req.body.creation_id; // Rename for clarity
    const email = req.query.email || req.body.email;
    const company = req.query.company || req.body.company;

    console.log("🧾 Received Payload:", {
      tempTable,
      rowId,
      email,
      company,
      updatedRow
    });

    if (!tempTable || !rowId || !updatedRow || !email || !company) {
      return res.status(400).json({ 
        error: 'Missing required fields', 
        details: { tempTable, rowId, email, company } 
      });
    }

    // 1. Get the current row data before update
    const currentRowQuery = `SELECT * FROM ${tempTable} WHERE id = $1`;
    const currentRow = await pool.query(currentRowQuery, [rowId]);

    if (currentRow.rowCount === 0) {
      return res.status(404).json({ error: 'Row not found' });
    }

    const previousValues = currentRow.rows[0];

    // 2. Build dynamic SET clause for update
    const keys = Object.keys(updatedRow);
    const setClause = keys.map((key, i) => `"${key}" = $${i + 1}`).join(', ');
    const values = keys.map(k => updatedRow[k]);
    values.push(rowId); // Add id as last param for WHERE clause

    // 3. Update the row
    const updateQuery = `
      UPDATE ${tempTable}
      SET ${setClause}
      WHERE id = $${values.length}
      RETURNING *;
    `;

    const result = await pool.query(updateQuery, values);

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Row not found during update' });
    }

    console.log("✅ Row updated successfully in DB");

    // 4. Log the update in journal_updates_log
    const updatedFields = {};
    const previousFieldValues = {};

    keys.forEach(key => {
      if (updatedRow[key] !== previousValues[key]) {
        updatedFields[key] = updatedRow[key];
        previousFieldValues[key] = previousValues[key];
      }
    });

    console.log("🔍 Changed Fields:", updatedFields);

    if (Object.keys(updatedFields).length > 0) {
      const logQuery = `
        INSERT INTO journal_updates_log 
        (temp_table, row_id, user_email, company_id, updated_fields, previous_values, reference_no, journal_no)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      `;

      await pool.query(logQuery, [
        tempTable,
        rowId,
        email,
        company,
        JSON.stringify(updatedFields),
        JSON.stringify(previousFieldValues),
        updatedRow.reference_no || previousValues.reference_no,
        updatedRow.journal_no || previousValues.journal_no
      ]);

      console.log("📝 Logged update to journal_updates_log");
    } else {
      console.log("ℹ️ No changes detected — nothing logged.");
    }

    res.json({ 
      message: 'Row updated successfully',
      updatedFields: updatedFields
    });

  } catch (err) {
    console.error('❌ Error in /api/updateJournalRow:', err);
    res.status(500).json({ error: 'Update failed', details: err.message });
  }
};


// Add new endpoint to get update history
exports.getJournalUpdateHistory = async (req, res) => {
  try {
    const { email, company, tempTable } = req.query;
    
    if (!email || !company) {
      return res.status(400).json({ error: 'Missing email or company' });
    }

    let query = `
      SELECT * FROM journal_updates_log 
      WHERE user_email = $1 AND company_id = $2
    `;
    const params = [email, company];

    if (tempTable) {
      query += ` AND temp_table = $3`;
      params.push(tempTable);
    }

    query += ` ORDER BY updated_at DESC`;

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    console.error('Error getting update history:', err);
    res.status(500).json({ error: 'Failed to fetch update history' });
  }
};

exports.getUserJournelUploads = async (req, res) => {
  try {
    const { email, company } = req.query;
    if (!email || !company) {
      return res.status(400).json({ error: 'Missing email or company' });
    }
    const result = await pool.query(`
      SELECT id, temp_table, uploaded_file, created_at
      FROM user_journal_temp_tables
      WHERE email = $1 AND company = $2
      ORDER BY created_at DESC
    `, [email, company]);
    res.json(result.rows);
  } catch (err) {
    console.error('Error getting uploads:', err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.deleteJournelUpload = async (req, res) => {
  try {
    const { table } = req.body;
    if (!table) {
      return res.status(400).json({ error: 'Table name required' });
    }
    await pool.query(`DROP TABLE IF EXISTS ${table}`);
    await pool.query(`DELETE FROM user_journal_temp_tables WHERE temp_table = $1`, [table]);
    res.json({ message: 'Upload deleted successfully' });
  } catch (err) {
    console.error('Error deleting upload:', err);
    res.status(500).json({ error: 'Database error' });
  }
};
