// src/index.js
import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { AuthProvider } from "react-oidc-context";
import App from "./App";
import { WebSocketProvider } from "./context/WebSocketProvider";

const cognitoConfig = {
  authority: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_lCMCna2RL",
  client_id: "7mdvqnncbbn2s8m668ip9jus5o",
  redirect_uri: "http://localhost:3000",
  response_type: "code",
  scope: "email openid phone",
};
ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <AuthProvider {...cognitoConfig}>
    <WebSocketProvider>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </WebSocketProvider>
    </AuthProvider>
  </React.StrictMode>
);
