// src/hooks/useUserType.js

import { useAuth } from "react-oidc-context";

export const useUserType = () => {
  const auth = useAuth();
  console.log("useUserType - auth:", auth);

  if (!auth.isAuthenticated) {
    return null;
  }

  const groups = auth.user?.profile?.["cognito:groups"] || [];
  console.log("User groups:", groups);

  if (groups.includes("Silver") || groups.includes("silver")) {
    return "silver";
  } if (groups.includes("Gold") || groups.includes("gold")) {
    return "gold";
  } if (groups.includes("Trial") || groups.includes("trial")) {
    return "trial";
  } 
  return  "trial";
};
