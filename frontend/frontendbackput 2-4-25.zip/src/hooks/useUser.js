import { useAuth } from "react-oidc-context";
import { useEffect, useState } from "react";

function useUser() {
  const auth = useAuth();
  const userEmail = auth?.user?.profile?.email;
  const [userType, setUserType] = useState("gold"); // Default to gold

  useEffect(() => {
    if (userEmail) {
      sessionStorage.setItem("userEmail", userEmail);
      // Example: get user type from token or backend if needed
      const storedType = sessionStorage.getItem("userType");
      if (storedType) {
        setUserType(storedType);
      } else {
        // TEMP: Hardcoded fallback (you can fetch from backend or decode token)
        setUserType("gold");
        sessionStorage.setItem("userType", "gold");
      }
    }
  }, [userEmail]);

  return { userEmail, userType };
}

export default useUser;
