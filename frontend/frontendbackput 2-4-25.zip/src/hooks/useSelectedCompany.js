import { useEffect, useState } from "react";

function useSelectedCompany(companies, initialSelected = "") {
  const [selectedCompany, setSelectedCompany] = useState(initialSelected);
  const [companyName, setCompanyName] = useState("");

  useEffect(() => {
    const storedCompany = sessionStorage.getItem("selectedCompany");
    const storedCompanyName = sessionStorage.getItem("selectedCompanyName");

    if (storedCompany && !selectedCompany) {
      setSelectedCompany(storedCompany);
      setCompanyName(storedCompanyName || "");
    }
  }, [selectedCompany]);

  const handleCompanyChange = (valueOrEvent) => {
    // Check if valueOrEvent is an event or direct value
    const companyId = valueOrEvent.target ? valueOrEvent.target.value : valueOrEvent;
    const selected = companies.find((c) => c.company_id === companyId || c.id === companyId);
    const name = selected?.company_name || selected?.name || "";

    setSelectedCompany(companyId);
    setCompanyName(name);

    sessionStorage.setItem("selectedCompany", companyId);
    sessionStorage.setItem("selectedCompanyName", name);
  };

  return { selectedCompany, companyName, handleCompanyChange };
}

export default useSelectedCompany;
