import React, { createContext, useContext } from "react";
import useWebSocket from "../hooks/useWebSocket"; // ✅ Custom hook

// Create the context
const WebSocketContext = createContext();

// Create a custom hook to use the WebSocket context
export const useWebSocketContext = () => {
  const context = useContext(WebSocketContext);
  if (!context) {
    throw new Error("useWebSocketContext must be used within a WebSocketProvider");
  }
  return context;
};

// Create the provider
export const WebSocketProvider = ({ children }) => {
  // ✅ Use your universal WebSocket hook with the correct URL
  const {
    wsStatus,
    pdfStatus,
    tempTables,
    tempTableData,
    fetchTempTables,
    fetchTempTableData,
    sendData,
    fetchCompanies,
    sendToTallyMessage,
    bankAccounts,
    ledgerOptions,
    fetchBank,
    sendUpdateMessage,
    fetchLedgerOptions,
    wsRef
  } = useWebSocket("ws://localhost:8000"); // Replace with your actual WebSocket URL if different

  const contextValue = {
    wsStatus,
    pdfStatus,
    tempTables,
    tempTableData,
    fetchTempTables,
    fetchTempTableData,
    sendToTallyMessage,
    sendData,
    bankAccounts,
    ledgerOptions,
    fetchBank,
    fetchCompanies,
    sendUpdateMessage,
    fetchLedgerOptions,
    wsRef,
  };

  return (
    <WebSocketContext.Provider value={contextValue}>
      {children}
    </WebSocketContext.Provider>
  );
};
