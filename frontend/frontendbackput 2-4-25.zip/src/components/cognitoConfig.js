// src/cognitoConfig.js
export const poolData = {
    UserPoolId: 'ap-south-1_lCMCna2RL',    // Replace with your Cognito User Pool ID
    ClientId: '7mdvqnncbbn2s8m668ip9jus5o'          // Replace with your Cognito App Client ID
  };
  