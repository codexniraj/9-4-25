
import React, { useEffect, useState } from 'react';
import './Journelexcelview.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import AddLedgerButton from './AddLedgerbutton';
import NavbarWithCompany from '../NavbarWithCompany';

function Journelexcelview() {
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [filterText, setFilterText] = useState('');
  const [tempTable, setTempTable] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [showMapping, setShowMapping] = useState(false);
  const [ledgerOptions, setLedgerOptions] = useState([]);
  const [invalidLedgers, setInvalidLedgers] = useState([]);
  const [selectedCompany, setSelectedCompany] = useState('');
  const [currentCompany, setCurrentCompany] = useState('');
  const [selectedRows, setSelectedRows] = useState([]);

  const [selectAll, setSelectAll] = useState(false);

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedRows([]);
    } else {
      const allIndexes = filteredData.map((_, index) => index);
      setSelectedRows(allIndexes);
    }
    setSelectAll(!selectAll);
  };


  useEffect(() => {
    const company = sessionStorage.getItem("selectedCompany");
    if (company) {
      setCurrentCompany(company);
    }
  }, []);

  useEffect(() => {
    const temp = sessionStorage.getItem('tempTable');
    if (temp) {
      setTempTable(temp);
      fetchData(temp);
      fetchLedgerNames();
    }
  }, []);

  useEffect(() => {
    if (filterText.trim() === '') {
      setFilteredData(data);
    } else {
      const lower = filterText.toLowerCase();
      const result = data.filter(row =>
        Object.values(row).some(val =>
          val && val.toString().toLowerCase().includes(lower)
        )
      );
      setFilteredData(result);
    }
  }, [filterText, data]);

  const fetchData = async (tableName) => {
    try {
      const res = await axios.get('http://localhost:3001/api/getJournalData', {
        params: { tempTable: tableName }
      });
      setData(res.data);
      setFilteredData(res.data);
      const uploadMeta = JSON.parse(sessionStorage.getItem('uploadMeta')) || {};
      setInvalidLedgers(uploadMeta.invalidLedgers || []);
    } catch (err) {
      setError('Failed to load data');
    }
  };

  const fetchLedgerNames = async () => {
    const currentCompany = sessionStorage.getItem("selectedCompany");
    const email = sessionStorage.getItem("userEmail");

    if (!currentCompany || !email) {
      console.error("Missing email or company for ledger fetch.");
      return;
    }

    try {
      const res = await axios.get('http://localhost:3001/api/getUserData', {
        params: { email, company: currentCompany }
      });
      const permanentLedgerNames = res.data.map(entry => entry.description?.toLowerCase().trim());

      const uploadRes = await axios.get('http://localhost:3001/api/getUserExcelLedgerUploads', {
        params: { email, company: currentCompany }
      });

      let tempLedgerNames = [];
      if (uploadRes.data.length > 0) {
        const latestTempTable = uploadRes.data[0].temp_table;
        const tempDataRes = await axios.get('http://localhost:3001/api/getJournalData', {
          params: { tempTable: latestTempTable }
        });
        tempLedgerNames = tempDataRes.data.map(row =>
          row.name?.toLowerCase().trim() || row.Name?.toLowerCase().trim()
        ).filter(Boolean);
      }

      const mergedLedgers = [...new Set([...permanentLedgerNames, ...tempLedgerNames])];
      setLedgerOptions(mergedLedgers);
    } catch (err) {
      console.error("Error fetching ledgers", err);
    }
  };

  const handleRowSelect = (rowIndex) => {
    const selectedRef = data[rowIndex]?.reference_no;
    if (!selectedRef) return;

    const relatedIndexes = data
      .map((row, i) => (row.reference_no === selectedRef ? i : null))
      .filter(i => i !== null);

    setSelectedRows(prev => {
      const allSelected = relatedIndexes.every(i => prev.includes(i));
      if (allSelected) {
        return prev.filter(i => !relatedIndexes.includes(i));
      } else {
        return Array.from(new Set([...prev, ...relatedIndexes]));
      }
    });
  };

  const isRowSelected = (rowIndex) => selectedRows.includes(rowIndex);

  const handleSave = async () => {
    if (selectedRows.length === 0) {
      setError("Please select at least one row to save.");
      return;
    }

    const rowsToValidate = selectedRows.map(i => data[i]);
    const hasInvalid = rowsToValidate.some(row => !ledgerOptions.includes(row.particulars?.toLowerCase().trim()));
    if (hasInvalid) {
      setError("Please resolve all red-marked ledgers before saving.");
      return;
    }

    let debit = 0, credit = 0;
    for (let row of rowsToValidate) {
      if (row.dr_cr === "Dr") debit += Number(row.amount || 0);
      else if (row.dr_cr === "Cr") credit += Number(row.amount || 0);
    }

    if (debit !== credit) {
      setError(`Dr/Cr mismatch: Debit = ${debit}, Credit = ${credit}`);
      return;
    }

    try {
      for (let rowIndex of selectedRows) {
        await axios.post("http://localhost:3001/api/updateJournalRow", {
          tempTable,
          id: data[rowIndex].id,     // ✅ Send stable ID
          updatedRow: data[rowIndex]
        });
      }
      setMessage("Selected rows saved successfully.");
      setError('');
    } catch (err) {
      setError("Save failed: " + err.message);
    }
  };

  const handleSendToTally = async () => {
    if (filteredData.some(row => !ledgerOptions.includes(row.particulars))) {
      setError("Cannot send to Tally: unresolved ledgers.");
      return;
    }
    try {
      const res = await axios.post('http://localhost:3001/api/sendJournalToTally', {
        company: currentCompany,
        tempTable: tempTable
      });
      setMessage(res.data.message || "Data sent to Tally successfully.");
    } catch (err) {
      setError("TallyConnector is offline or failed to receive data.");
    }
  };

  const formatDate = (value) => {
    if (!value) return '';
    if (typeof value === 'number') {
      const jsDate = new Date((value - 25569) * 86400 * 1000);
      return jsDate.toISOString().split('T')[0];
    }
    const parsed = new Date(value);
    if (!isNaN(parsed.getTime())) {
      return parsed.toISOString().split('T')[0];
    }
    return '';
  };

  const handleCellChange = (rowIndex, key, value) => {
    const updated = [...data];
    updated[rowIndex][key] = value;
    setData(updated);
    setFilteredData(updated);
  };

  return (
    <div className="excelview-wrapper container-fluid p-4">
      <NavbarWithCompany selectedCompany={selectedCompany} setSelectedCompany={setSelectedCompany} lockCompany={true} />
      <h2 className="mb-4 text-center">Journal Excel Data Review</h2>

      <div className="action-buttons d-flex justify-content-center gap-3 mb-4">
        <button className="btn btn-outline-primary">Filter</button>
        <button className="btn btn-outline-secondary" onClick={() => setShowMapping(true)}>Mapping</button>
        <button className="btn btn-success" onClick={handleSave}>Save</button>
        <button className="btn btn-warning" onClick={handleSendToTally}>Send To Tally</button>
        <AddLedgerButton onAdd={(newLedger) => setLedgerOptions([...ledgerOptions, newLedger])} />
      </div>

      <div className="filter-section mb-3 text-center">
        <input
          type="text"
          className="form-control w-50 mx-auto"
          placeholder="Filter by any field..."
          value={filterText}
          onChange={(e) => setFilterText(e.target.value)}
        />
      </div>

      {error && <div className="alert alert-danger">{error}</div>}
      {message && <div className="alert alert-success">{message}</div>}

      <div className="table-responsive">
        <table className="table table-bordered table-sm table-striped">
          <thead className="table-dark">
            <tr>
              <th><input type="checkbox" checked={selectAll} onChange={handleSelectAll} /></th>
              <th>Sr. No.</th>
              {filteredData[0] && Object.keys(filteredData[0]).map((key) => (
                <th key={key}>{key.replace(/_/g, ' ')}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filteredData.map((row, rowIndex) => (
              <tr key={rowIndex}>
                <td>
                  <input type="checkbox" checked={isRowSelected(rowIndex)} onChange={() => handleRowSelect(rowIndex)} />
                </td>
                <td>{rowIndex + 1}</td>
                {Object.entries(row).map(([key, val], colIndex) => {
                  const lowerKey = key.toLowerCase();
                  const isLedger = lowerKey === 'particulars';
                  const isDate = lowerKey === 'date';
                  const isDrCr = lowerKey === 'dr_cr';
                  return (
                    <td key={colIndex} className={isLedger && !ledgerOptions.includes(val?.toLowerCase().trim()) ? 'bg-danger text-white' : ''}>
                      {isDate ? (
                        <input type="date" className="form-control form-control-sm" value={formatDate(val)} onChange={(e) => handleCellChange(rowIndex, key, e.target.value)} />
                      ) : isDrCr ? (
                        <select className="form-select form-select-sm" value={val} onChange={(e) => handleCellChange(rowIndex, key, e.target.value)}>
                          <option value="">Select</option>
                          <option value="Dr">Dr</option>
                          <option value="Cr">Cr</option>
                        </select>
                      ) : isLedger ? (
                        <div className="d-flex align-items-center">
                          <input className={`form-control form-control-sm ${!ledgerOptions.includes(val) ? 'border-danger' : ''}`} value={val} onChange={(e) => handleCellChange(rowIndex, key, e.target.value)} />
                          {!ledgerOptions.includes(val) && <span className="ms-2 text-danger" title="Add Ledger" style={{ cursor: 'pointer' }}>ℹ️</span>}
                        </div>
                      ) : (
                        <input type="text" value={val || ''} onChange={(e) => handleCellChange(rowIndex, key, e.target.value)} className="form-control form-control-sm" />
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Journelexcelview;
