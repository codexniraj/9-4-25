// AddLedgerbutton.js (Updated with full 34 group logic + dynamic fields + styled UI)
import React, { useState, useEffect } from 'react';
import './AddLedgerbutton.css';
import axios from 'axios';

const ledgerGroups = [
  "Bank Accounts", "Bank OCC Alc", "Bank OD Alc", "Branch / Divisions", "Capital Account",
  "Cash-in-Hand", "Current Assets", "Current Liabilities", "Deposits (Asset)", "Direct Expenses",
  "Direct Incomes", "Duties & Taxes", "Expenses (Direct)", "Expenses (Indirect)", "Fixed Assets",
  "Income (Direct)", "Income (Indirect)", "Indirect Expenses", "Indirect Incomes", "Investments",
  "Loans & Advances (Asset)", "Loans (Liability)", "Misc. Expenses (ASSET)", "Provisions",
  "Purchase Accounts", "Reserves & Surplus", "Retained Earnings", "Sales Accounts",
  "Secured Loans", "Stock-in-Hand", "Sundry Creditors", "Sundry Debtors", "Suspense Alc", "Unsecured Loans"
];

const requiredFieldsByLedgerGroup = {
  "Bank Accounts": ["Account Holder Name", "Alc No-", "IFS code", "SWIFT code", "Bank Name", "Branch"],
  "Bank OCC Alc": ["Account Holder Name", "IFS code", "SWIFT code", "Bank Name"],
  "Bank OD Alc": ["Account Holder Name", "IFS code", "Bank Name"],
  "Branch / Divisions": ["Address", "State", "Pincode"],
  "Capital Account": ["Mailing name", "PAN/IT No", "GSTIN/UIN", "GST Applicable"],
  "Cash-in-Hand": ["State"],
  "Current Assets": ["Mailing name"],
  "Current Liabilities": ["Mailing name"],
  "Deposits (Asset)": ["Mailing name", "Address", "PAN/IT No"],
  "Direct Expenses": ["GST Applicable", "Taxability"],
  "Direct Incomes": ["GST Applicable", "Taxability"],
  "Duties & Taxes": ["Type of Duty &Tax", "Percentage of calculation"],
  "Expenses (Direct)": ["GST Applicable"],
  "Expenses (Indirect)": ["GST Applicable"],
  "Fixed Assets": ["Mailing name", "Address"],
  "Income (Direct)": ["GST Applicable"],
  "Income (Indirect)": ["GST Applicable"],
  "Indirect Expenses": ["GST Applicable"],
  "Indirect Incomes": ["GST Applicable"],
  "Investments": ["Mailing name"],
  "Loans & Advances (Asset)": ["Mailing name"],
  "Loans (Liability)": ["Mailing name"],
  "Misc. Expenses (ASSET)": ["Mailing name"],
  "Provisions": ["Mailing name"],
  "Purchase Accounts": ["GST Applicable", "Taxability", "HSN/SAC"],
  "Reserves & Surplus": ["Mailing name"],
  "Retained Earnings": ["Mailing name"],
  "Sales Accounts": ["GST Applicable", "Taxability", "HSN/SAC", "Type of Supply"],
  "Secured Loans": ["Mailing name"],
  "Stock-in-Hand": ["Mailing name"],
  "Sundry Creditors": ["PAN/IT No", "GSTIN/UIN", "Mailing name", "Address", "State", "Pincode"],
  "Sundry Debtors": ["PAN/IT No", "GSTIN/UIN", "Mailing name", "Address", "State", "Pincode"],
  "Suspense Alc": ["Mailing name"],
  "Unsecured Loans": ["Mailing name"]
};

function AddLedgerButton({ onAdd }) {
  const [showModal, setShowModal] = useState(false);
  const [ledgerName, setLedgerName] = useState('');
  const [selectedGroup, setSelectedGroup] = useState('');
  const [dynamicFields, setDynamicFields] = useState([]);
  const [fieldValues, setFieldValues] = useState({});

  const userEmail = sessionStorage.getItem("userEmail");
  const selectedCompany = sessionStorage.getItem("selectedCompany");

  useEffect(() => {
    setDynamicFields(requiredFieldsByLedgerGroup[selectedGroup] || []);
    setFieldValues({});
  }, [selectedGroup]);

  const handleFieldChange = (field, value) => {
    setFieldValues(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    const payload = {
      email: userEmail,
      company: selectedCompany,
      data: [{
        Name: ledgerName,
        Under: selectedGroup,
        ...dynamicFields.reduce((acc, field) => {
          acc[field] = fieldValues[field] || null;
          return acc;
        }, {})
      }],
      uploadedFileName: `ManualEntry_${Date.now()}.xlsx`
    };

    try {
      await axios.post('/api/uploadExcelLedger', payload);
      alert('Ledger saved successfully!');
      setShowModal(false);
      setLedgerName('');
      setSelectedGroup('');
      setFieldValues({});
    } catch (err) {
      console.error("Error saving ledger:", err);
      alert("Error saving ledger.");
    }
  };

  const handleSendToTally = async () => {
    try {
      const mockTempTable = `ledger_temp_${userEmail.replace(/[^a-zA-Z0-9]/g, '_')}_manual`;
      await axios.post('/api/sendLedgerToTally', {
        company: selectedCompany,
        tempTable: mockTempTable
      });
      alert('Ledger sent to Tally successfully!');
      setShowModal(false);
    } catch (err) {
      console.error("Error sending to Tally:", err);
      alert("Error sending to Tally.");
    }
  };

  return (
    <>
      <button className="btn btn-info shadow rounded-pill px-4 py-2 fw-bold" onClick={() => setShowModal(true)}>➕ Add Ledger</button>

      {showModal && (
        <div className="ledger-modal">
          <div className="ledger-modal-content p-4 rounded shadow-lg bg-white">
            <h4 className="mb-3">🧾 Add New Ledger</h4>

            <input
              type="text"
              className="form-control mb-3"
              placeholder="Enter ledger name"
              value={ledgerName}
              onChange={(e) => setLedgerName(e.target.value)}
            />

            <select
              className="form-select mb-3"
              value={selectedGroup}
              onChange={(e) => setSelectedGroup(e.target.value)}>
              <option value="">Select Ledger Group</option>
              {ledgerGroups.map(group => (
                <option key={group}>{group}</option>
              ))}
            </select>

            {dynamicFields.map((field, index) => (
              <input
                key={index}
                type="text"
                className="form-control mb-2"
                placeholder={field}
                value={fieldValues[field] || ''}
                onChange={(e) => handleFieldChange(field, e.target.value)}
              />
            ))}
            <div className="button-row">
              <button className="btn btn-outline-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSave}>💾 Save</button>
              <button className="btn btn-success" onClick={handleSendToTally}>📤 Send to Tally</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default AddLedgerButton;
