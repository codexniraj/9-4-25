import React, { useState, useEffect } from 'react';
import axios from 'axios';
import NavbarWithCompany from '../NavbarWithCompany';
import './LedgerExcelview.css';


const ledgerGroups = ["Bank Accounts", "Bank OCC Alc", "Bank OD Alc", "Branch / Divisions", "Capital Account", "Cash-in-Hand", "Current Assets", "Current Liabilities", "Deposits (Asset)", "Direct Expenses", "Direct Incomes", "Duties & Taxes", "Expenses (Direct)", "Expenses (Indirect)", "Fixed Assets", "Income (Direct)", "Income (Indirect)", "Indirect Expenses", "Indirect Incomes", "Investments", "Loans & Advances (Asset)", "Loans (Liability)", "Misc. Expenses (ASSET)", "Provisions", "Purchase Accounts", "Reserves & Surplus", "Retained Earnings", "Sales Accounts", "Secured Loans", "Stock-in-Hand", "Sundry Creditors", "Sundry Debtors", "Suspense Alc", "Unsecured Loans"];
const yesNo = ["Yes", "No"];
const registrationTypes = ["Unknown", "Composition", "Consumer", "Regular", "Unregistered"];
const typeOfLedgers = ["Not Applicable", "Discount", "Invoice Rounding"];
const gstApplicable = ["Applicable", "Not Applicable", "Undefined"];
const taxabilityOptions = ["Unknown", "Exempt", "Nil Rated", "Taxable"];

const toHeader = (key) => key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());

function LedgerExcelView() {
  const [data, setData] = useState([]);
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [tempTable, setTempTable] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [selectedCompany, setSelectedCompany] = useState('');
  const userEmail = sessionStorage.getItem('userEmail');

  useEffect(() => {
    const temp = sessionStorage.getItem('tempTable');
    setTempTable(temp);
    fetchData(temp);
    const company = sessionStorage.getItem('selectedCompany');
    if (company) setSelectedCompany(company);
  }, []);

  const fetchData = async (tableName) => {
    const res = await axios.get('/api/tempLedgers', { params: { tempTable: tableName } });
    setData(res.data);
  };

  const handleCheckboxChange = (idx) => {
    setSelectedRows(prev => {
      const updated = new Set(prev);
      updated.has(idx) ? updated.delete(idx) : updated.add(idx);
      return updated;
    });
  };

  const handleSelectAll = (checked) => {
    setSelectedRows(checked ? new Set(data.map((_, idx) => idx)) : new Set());
  };

  const handleSave = async () => {
    const rowsToSave = data.filter((_, idx) => selectedRows.has(idx));
    try {
      await axios.post('/api/saveLedgerRows', { email: userEmail, company: selectedCompany, tempTable, rows: rowsToSave });
      setMessage('Rows saved successfully!');
      setSelectedRows(new Set());
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to save rows.');
    }
  };

  const handleSendToTally = async () => {
    try {
      await axios.post('/api/sendLedgerToTally', {
        email: userEmail,
        company: selectedCompany,
        tempTable,
      });
      setMessage('Data sent to Tally successfully!');
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to send data to Tally.');
    }
  };

  const handleCellChange = (idx, key, value) => {
    setData(prev => prev.map((row, i) => (i === idx ? { ...row, [key]: value } : row)));
  };

  return (
    <div className="ledger-excel-view container-fluid p-4">
      <NavbarWithCompany
        selectedCompany={selectedCompany}
        setSelectedCompany={setSelectedCompany}
        lockCompany={true}
      />
      <h2 className="mb-4 text-center">Ledger Excel Data Review</h2>

      {message && <div className="alert alert-success">{message}</div>}
      {error && <div className="alert alert-danger">{error}</div>}

      <div className="buttons mb-4">
        <button className="btn btn-success" disabled={!selectedRows.size} onClick={handleSave}>Save</button>
        <button className="btn btn-warning ms-2" disabled={!selectedRows.size} onClick={handleSendToTally}>Send to Tally</button>
      </div>

      <div className="table-responsive">
        <table className="table table-bordered table-striped">
          <thead className="table-dark">
            <tr>
              <th><input type="checkbox" onChange={(e) => handleSelectAll(e.target.checked)} /></th>
              {data[0] && Object.keys(data[0]).map(key => <th key={key}>{toHeader(key)}</th>)}
            </tr>
          </thead>
          <tbody>
            {data.map((row, idx) => (
              <tr key={idx}>
                <td><input type="checkbox" checked={selectedRows.has(idx)} onChange={() => handleCheckboxChange(idx)} /></td>
                {Object.entries(row).map(([key, val]) => (
                  <td key={key}>
                  {key === "parent" ? (
                    <select className="form-select" value={val || ''} onChange={(e) => handleCellChange(idx, key, e.target.value)}>
                      <option value="">Select Parent</option>
                      {ledgerGroups.map(o => <option key={o}>{o}</option>)}
                    </select>
                  ) : key === "bill_by_bill" || key === "inventory_affected" || key === "set_alter_gst_details" ? (
                    <select className="form-select" value={val || ''} onChange={(e) => handleCellChange(idx, key, e.target.value)}>
                      <option value="">Select Option</option>
                      {yesNo.map(o => <option key={o}>{o}</option>)}
                    </select>
                  ) : key === "registration_type" ? (
                    <select className="form-select" value={val || ''} onChange={(e) => handleCellChange(idx, key, e.target.value)}>
                      <option value="">Select Registration Type</option>
                      {registrationTypes.map(o => <option key={o}>{o}</option>)}
                    </select>
                  ) : key === "type_of_ledger" ? (
                    <select className="form-select" value={val || ''} onChange={(e) => handleCellChange(idx, key, e.target.value)}>
                      <option value="">Select Type of Ledger</option>
                      {typeOfLedgers.map(o => <option key={o}>{o}</option>)}
                    </select>
                  ) : key === "gst_applicable" ? (
                    <select className="form-select" value={val || ''} onChange={(e) => handleCellChange(idx, key, e.target.value)}>
                      <option value="">Select GST Applicable</option>
                      {gstApplicable.map(o => <option key={o}>{o}</option>)}
                    </select>
                  ) : key === "taxability" ? (
                    <select className="form-select" value={val || ''} onChange={(e) => handleCellChange(idx, key, e.target.value)}>
                      <option value="">Select Taxability</option>
                      {taxabilityOptions.map(o => <option key={o}>{o}</option>)}
                    </select>
                  ) : (
                    <input className="form-control" value={val || ''} onChange={(e) => handleCellChange(idx, key, e.target.value)} />
                  )}
                </td>
                
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default LedgerExcelView;
