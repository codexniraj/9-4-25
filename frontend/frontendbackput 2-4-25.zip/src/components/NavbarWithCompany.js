import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import { FaBuilding } from "react-icons/fa";

// 🧠 Custom Hooks
import useUser from "../hooks/useUser";
import { useUserType } from "../hooks/useUserType";
import useCompanies from "../hooks/useCompanies";
import useSelectedCompany from "../hooks/useSelectedCompany";

function NavbarWithCompany({ lockCompany = false }) {
  const { userEmail } = useUser(); // stores email in sessionStorage
  const userType = useUserType(); // gets "silver", "gold", "trial"
  const { companies, loading } = useCompanies(userEmail, userType); // fetches company list
  const {
    selectedCompany,
    companyName,
    handleCompanyChange,
  } = useSelectedCompany(companies); // manages selection & sessionStorage

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark border-bottom shadow-sm py-3 px-4">
      <div className="container-fluid d-flex justify-content-between align-items-center">
        <div className="navbar-brand d-flex align-items-center gap-2 fw-bold text-white">
          <FaBuilding size={22} />
          Tallyfy.ai
        </div>

        <div className="d-flex align-items-center gap-3">
          <div className="d-flex align-items-center">
            <label className="me-2 text-light fw-semibold">Select Company:</label>
            {loading ? (
              <p className="text-light m-0">Loading...</p>
            ) : (
              <select
                className="form-select shadow-sm"
                style={{ minWidth: "250px" }}
                value={selectedCompany}
                onChange={handleCompanyChange}
                disabled={lockCompany}
              >
                <option value="">-- Choose Company --</option>
                {companies.map((c) => (
                  <option key={c.company_id} value={c.company_id}>
                    {c.company_name}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Company Name Badge */}
          {companyName && (
            <span className="badge bg-success text-light">
              {companyName}
            </span>
          )}

          {/* User Email Badge */}
          {userEmail && (
            <span className="badge bg-primary text-light">
              {userEmail}
            </span>
          )}
        </div>
      </div>
    </nav>
  );
}

export default NavbarWithCompany;
