import React, { useState, useCallback, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import { useUserType } from "../../../hooks/useUserType";
import { useWebSocketContext } from "../../../context/WebSocketProvider.js";

const PreviewPage = () => {
  const { tempTableData, fetchTempTableData, sendToTallyMessage, sendUpdateMessage } = useWebSocketContext();
  const location = useLocation();
  const navigate = useNavigate();
  const userType = useUserType();
  const hasFetchedTempTableData = useRef(false);

  const {
    previewData: initialPreviewData = [],
    statistics: initialStatistics = {
      totalTransactions: 0,
      pendingTransactions: 0,
      savedTransactions: 0,
      tallyTransactions: 0,
    },
    ledgerOptions: initialLedgerOptions = [],
    tempTable, // upload id
    selectedCompany,
  } = location.state || {};

  // previewData and statistics come from API/WS
  const [previewData, setPreviewData] = useState(initialPreviewData);
  const [statistics, setStatistics] = useState(initialStatistics);
  // Since ledgerOptions are an array of strings, we use them directly.
  const [ledgerOptions] = useState(initialLedgerOptions);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [selectedTransactions, setSelectedTransactions] = useState([]);

  const [filters, setFilters] = useState({
    hideTallySynced: false,
    savedRecords: false,
    blankRecords: false,
    unsavedRecords: false,
  });

  const [columnFilters, setColumnFilters] = useState({
    dateFrom: "",
    dateTo: "",
    description: "",
    type: "",
    amountFrom: "",
    amountTo: "",
    assignedLedger: "",
  });

  const formatDate = (dateStr) => {
    if (!dateStr) return "";
    return new Date(dateStr).toLocaleDateString("en-GB");
  };

  const fetchTempDataFromAPI = useCallback(async () => {
    if (!tempTable) {
      console.error("No temp table available");
      return;
    }
    try {
      const resp = await axios.get(`/api/tempLedgers?tempTable=${tempTable}`);
      console.log("Fetched previewData in PreviewPage:", resp.data);
      const dataWithOriginal = resp.data.map((row) => ({
        ...row,
        originalAssignedLedger: row.assigned_ledger,
      }));
      setPreviewData(dataWithOriginal);
      setSelectedTransactions([]);
      const total = dataWithOriginal.length;
      const pending = dataWithOriginal.filter((row) => !row.assigned_ledger).length;
      const saved = dataWithOriginal.filter((row) => row.assigned_ledger.trim() !== "").length;
      setStatistics({
        totalTransactions: total,
        pendingTransactions: pending,
        savedTransactions: saved,
        tallyTransactions: initialStatistics.tallyTransactions,
      });
      const tallyResp = await axios.get(`/api/tallyTransactions?tempTable=${tempTable}`);
      setStatistics((prev) => ({
        ...prev,
        tallyTransactions: tallyResp.data.count || 0,
      }));
    } catch (err) {
      console.error("Error fetching preview data:", err);
    }
  }, [tempTable, initialStatistics.tallyTransactions]);

  const applyGeneralFilters = (data) => {
    return data.filter((row) => {
      if (filters.hideTallySynced && row.status === "sent") return false;
      if (filters.savedRecords && row.assigned_ledger.trim() === "") return false;
      if (filters.blankRecords && row.assigned_ledger.trim() !== "") return false;
      if (filters.unsavedRecords && row.assigned_ledger === row.originalAssignedLedger) return false;
      return true;
    });
  };

  const applyColumnFilters = (data) => {
    return data.filter((row) => {
      if (columnFilters.dateFrom) {
        const fromDate = new Date(columnFilters.dateFrom);
        const rowDate = new Date(row.transaction_date);
        if (rowDate < fromDate) return false;
      }
      if (columnFilters.dateTo) {
        const toDate = new Date(columnFilters.dateTo);
        const rowDate = new Date(row.transaction_date);
        if (rowDate > toDate) return false;
      }
      if (columnFilters.description) {
        if (!row.description.toLowerCase().includes(columnFilters.description.toLowerCase()))
          return false;
      }
      if (columnFilters.type) {
        if (row.transaction_type !== columnFilters.type) return false;
      }
      if (columnFilters.amountFrom) {
        if (parseFloat(row.amount) < parseFloat(columnFilters.amountFrom)) return false;
      }
      if (columnFilters.amountTo) {
        if (parseFloat(row.amount) > parseFloat(columnFilters.amountTo)) return false;
      }
      if (columnFilters.assignedLedger) {
        if (row.assigned_ledger !== columnFilters.assignedLedger) return false;
      }
      return true;
    });
  };

  const filteredData = applyColumnFilters(applyGeneralFilters(previewData));

  const handleColumnFilterChange = (filterName, value) => {
    setColumnFilters((prev) => ({
      ...prev,
      [filterName]: value,
    }));
  };

  const handleFilterChange = (filterName) => {
    setFilters((prev) => ({
      ...prev,
      [filterName]: !prev[filterName],
    }));
  };

  const handleSaveUpdates = async () => {
    if (!previewData || previewData.length === 0) {
      console.warn("No preview data to update");
      return;
    }
    if (!tempTable) {
      console.warn("No temp table available for saving updates");
      return;
    }
    const updatedData = previewData.map((row) => ({
      transaction_date: row.transaction_date,
      transaction_type: row.transaction_type,
      description: row.description,
      amount: row.amount,
      assignedLedger: row.assigned_ledger,
      email: row.email,
      company: row.company,
      bank_account: row.bank_account,
    }));
    try {
      if (userType === "gold") {
        const resp = await axios.post("/api/updateTempExcel", {
          tempTable: tempTable,
          data: updatedData,
        });
        console.log("Updated data in temp table:", resp.data);
      } else if (userType === "silver") {
        sendUpdateMessage(tempTable, updatedData);
        console.log("Sent update message via WebSocket.");
      }
      setHasUnsavedChanges(false);
      alert("Changes saved successfully.");
      if (userType === "gold") {
        fetchTempDataFromAPI();
      } else if (userType === "silver") {
        fetchTempTableData(tempTable);
      }
    } catch (err) {
      console.error("Error updating temp table:", err);
      alert("Error saving changes. Please try again.");
    }
  };

  const handleSendToTally = async () => {
    if (hasUnsavedChanges) {
      alert("Please save your changes before sending to Tally.");
      return;
    }
    if (!tempTable || !selectedCompany) {
      alert("Please ensure company is selected and data is loaded.");
      return;
    }
    if (userType === "gold") {
      try {
        const response = await axios.post("/api/sendToTally", {
          company: selectedCompany,
          tempTable: tempTable,
          selectedTransactions: selectedTransactions.length > 0 ? selectedTransactions : null,
        });
        console.log("Sent to Tally response:", response.data);
        alert("Data successfully sent to Tally!");
        fetchTempDataFromAPI();
      } catch (err) {
        console.error("Error sending to Tally:", err);
        alert("Error sending data to Tally. Please try again.");
      }
    } else if (userType === "silver") {
      sendToTallyMessage(selectedCompany, tempTable, selectedTransactions);
      console.log("Sent send_to_tally message via WebSocket.");
    }
  };

  const handleLedgerChange = (e, idx) => {
    const newData = [...previewData];
    newData[idx].assigned_ledger = e.target.value;
    setPreviewData(newData);
    setHasUnsavedChanges(true);
  };

  const handleTypeChange = (e, idx) => {
    const newData = [...previewData];
    newData[idx].transaction_type = e.target.value;
    setPreviewData(newData);
    setHasUnsavedChanges(true);
  };

  const toggleSelectTransaction = (transactionId) => {
    setSelectedTransactions((prevSelected) => {
      if (prevSelected.includes(transactionId)) {
        return prevSelected.filter((id) => id !== transactionId);
      } else {
        return [...prevSelected, transactionId];
      }
    });
  };

  const toggleSelectAll = () => {
    if (selectedTransactions.length === previewData.length) {
      setSelectedTransactions([]);
    } else {
      const allIds = previewData.map((row) => row.id);
      setSelectedTransactions(allIds);
    }
  };

  const handleBulkAssign = (ledger) => {
    if (!ledger) return;
    const newData = previewData.map((row) =>
      selectedTransactions.includes(row.id)
        ? { ...row, assigned_ledger: ledger }
        : row
    );
    setPreviewData(newData);
    setHasUnsavedChanges(true);
  };

  const handleDeleteTransaction = async (transactionId) => {
    if (!tempTable) {
      alert("Temp table not available.");
      return;
    }
    try {
      const response = await axios.post("/api/deleteTransaction", {
        tempTable,
        transactionId,
      });
      console.log("Delete response:", response.data);
      alert("Transaction deleted successfully.");
      fetchTempDataFromAPI();
    } catch (err) {
      console.error("Error deleting transaction:", err);
      alert("Error deleting transaction. Please try again.");
    }
  };

  useEffect(() => {
    hasFetchedTempTableData.current = false;
  }, [tempTable]);

  useEffect(() => {
    console.log("PreviewPage effect fired:", { tempTable, userType });
    if (tempTable && userType === "silver" && !hasFetchedTempTableData.current) {
      fetchTempTableData(tempTable);
      hasFetchedTempTableData.current = true;
    } else if (tempTable && userType === "gold") {
      fetchTempDataFromAPI();
    }
  }, [tempTable, userType, fetchTempTableData, fetchTempDataFromAPI]);

  useEffect(() => {
    if (tempTableData.length > 0) {
      const dataWithOriginal = tempTableData.map((row) => ({
        ...row,
        originalAssignedLedger: row.assigned_ledger,
      }));
      setPreviewData(dataWithOriginal);
    }
  }, [tempTableData]);

  return (
    <div className="preview-page">
      <h2>Data Preview (From Temp Table)</h2>

      {/* General Filters Section */}
      <div className="general-filters">
        <h3>General Filters</h3>
        <label>
          <input
            type="checkbox"
            checked={filters.hideTallySynced}
            onChange={() => handleFilterChange("hideTallySynced")}
          />
          Hide Tally Synced Records
        </label>
        <label>
          <input
            type="checkbox"
            checked={filters.savedRecords}
            onChange={() => handleFilterChange("savedRecords")}
          />
          Saved Records
        </label>
        <label>
          <input
            type="checkbox"
            checked={filters.blankRecords}
            onChange={() => handleFilterChange("blankRecords")}
          />
          Blank Records
        </label>
        <label>
          <input
            type="checkbox"
            checked={filters.unsavedRecords}
            onChange={() => handleFilterChange("unsavedRecords")}
          />
          Unsaved Records
        </label>
      </div>

      {/* Bulk Assignment Section */}
      <div className="bulk-assign">
        <label>Bulk Assign Ledger to Selected:</label>
        <select onChange={(e) => handleBulkAssign(e.target.value)} defaultValue="">
          <option value="">--Select Ledger--</option>
          {ledgerOptions.map((ledger, index) => (
            <option key={index} value={ledger}>
              {ledger}
            </option>
          ))}
        </select>
      </div>

      <div className="table-wrapper">
        <table className="preview-table">
          <thead>
            <tr>
              <th>
                <input
                  type="checkbox"
                  checked={
                    previewData.length > 0 &&
                    selectedTransactions.length === previewData.length
                  }
                  onChange={toggleSelectAll}
                />
              </th>
              <th>Transaction Date</th>
              <th>Type (Receipt/Payment/Contra Withdraw/Contra Deposit)</th>
              <th>Description</th>
              <th>Amount</th>
              <th>Assigned Ledger</th>
              <th>Actions</th>
            </tr>
            {/* Column Filters Row */}
            <tr>
              <th></th>
              <th>
                <input
                  type="date"
                  placeholder="From"
                  value={columnFilters.dateFrom}
                  onChange={(e) =>
                    handleColumnFilterChange("dateFrom", e.target.value)
                  }
                  style={{ width: "48%" }}
                />
                <input
                  type="date"
                  placeholder="To"
                  value={columnFilters.dateTo}
                  onChange={(e) =>
                    handleColumnFilterChange("dateTo", e.target.value)
                  }
                  style={{ width: "48%", marginLeft: "4%" }}
                />
              </th>
              <th>
                <select
                  value={columnFilters.type}
                  onChange={(e) =>
                    handleColumnFilterChange("type", e.target.value)
                  }
                >
                  <option value="">All</option>
                  <option value="receipt">Receipt</option>
                  <option value="payment">Payment</option>
                  <option value="contra withdraw">Contra Withdraw</option>
                  <option value="contra deposit">Contra Deposit</option>
                </select>
              </th>
              <th>
                <input
                  type="text"
                  placeholder="Search description..."
                  value={columnFilters.description}
                  onChange={(e) =>
                    handleColumnFilterChange("description", e.target.value)
                  }
                />
              </th>
              <th>
                <input
                  type="number"
                  placeholder="Min"
                  value={columnFilters.amountFrom}
                  onChange={(e) =>
                    handleColumnFilterChange("amountFrom", e.target.value)
                  }
                  style={{ width: "48%" }}
                />
                <input
                  type="number"
                  placeholder="Max"
                  value={columnFilters.amountTo}
                  onChange={(e) =>
                    handleColumnFilterChange("amountTo", e.target.value)
                  }
                  style={{ width: "48%", marginLeft: "4%" }}
                />
              </th>
              <th>
                <select
                  value={columnFilters.assignedLedger}
                  onChange={(e) =>
                    handleColumnFilterChange("assignedLedger", e.target.value)
                  }
                >
                  <option value="">All</option>
                  {ledgerOptions.map((ledger, index) => (
                    <option key={index} value={ledger}>
                      {ledger}
                    </option>
                  ))}
                </select>
              </th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filteredData.length > 0 ? (
              filteredData.map((row, idx) => (
                <tr key={idx}>
                  <td>
                    <input
                      type="checkbox"
                      disabled={row.status === "sent"}
                      checked={selectedTransactions.includes(row.id)}
                      onChange={() => toggleSelectTransaction(row.id)}
                    />
                  </td>
                  <td>{row.transaction_date ? formatDate(row.transaction_date) : ""}</td>
                  <td>
                    <select
                      value={row.transaction_type || ""}
                      onChange={(e) => handleTypeChange(e, idx)}
                      disabled={row.status === "sent"}
                    >
                      <option value="">--Select Type--</option>
                      <option value="receipt">Receipt</option>
                      <option value="payment">Payment</option>
                      <option value="contra withdraw">Contra Withdraw</option>
                      <option value="contra deposit">Contra Deposit</option>
                    </select>
                  </td>
                  <td>{row.description || ""}</td>
                  <td>{row.amount || ""}</td>
                  <td>
                    <select
                      value={row.assigned_ledger || ""}
                      onChange={(e) => handleLedgerChange(e, idx)}
                      disabled={row.status === "sent"}
                    >
                      <option value="">--Select Ledger--</option>
                      {ledgerOptions.map((ledger, index) => (
                        <option key={index} value={ledger}>
                          {ledger}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <button
                      onClick={() => handleDeleteTransaction(row.id)}
                      disabled={row.status === "sent"}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7" style={{ textAlign: "center" }}>
                  No transactions found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="button-group">
        <button className="btn btn-save" onClick={handleSaveUpdates}>
          Save Changes
        </button>
        <button
          className={`btn btn-tally ${hasUnsavedChanges ? "btn-disabled" : ""}`}
          onClick={handleSendToTally}
          disabled={hasUnsavedChanges}
        >
          Send to Tally
        </button>
      </div>

      <div className="statistics">
        <h3>Statistics</h3>
        <p>Total Transactions: {statistics.totalTransactions}</p>
        <p>Pending Transactions: {statistics.pendingTransactions}</p>
        <p>Saved Transactions: {statistics.savedTransactions}</p>
        <p>Sent to Tally: {statistics.tallyTransactions}</p>
      </div>
    </div>
  );
};

export default PreviewPage;
