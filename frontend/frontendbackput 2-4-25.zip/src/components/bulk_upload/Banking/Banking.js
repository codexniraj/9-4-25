import React, { useEffect, useState } from "react";
import { useAuth } from "react-oidc-context";
import { Navigate } from "react-router-dom";
import Sidebar from "../../../components/Sidebar";
import NavbarWithCompany from "../../../components/NavbarWithCompany";
import ExcelUpload from "./ExcelUpload";
import { useUserType } from "../../../hooks/useUserType";
import useSelectedCompany from "../../../hooks/useSelectedCompany";
import useCompanies from "../../../hooks/useCompanies";
import useUser from "../../../hooks/useUser";
import { useWebSocketContext } from "../../../context/WebSocketProvider";
import "./Banking.css";

function Banking() {
  const auth = useAuth();
  const { userEmail } = useUser();
  const userType = useUserType(); // "gold", "silver", "trial"
  const isSilver = userType === "silver";
  const { wsStatus } = useWebSocketContext();

  const { companies, loading } = useCompanies(userEmail, userType);
  const {
    selectedCompany,
    companyName,
    handleCompanyChange,
  } = useSelectedCompany(companies);

  const [wsRefresh, setWsRefresh] = useState(0);

  // Reconnect WebSocket manually if TallyConnector isn't up (only silver)
  const shouldShowReconnect =
    isSilver && wsStatus && wsStatus !== "Connected" && companies.length === 0;

  useEffect(() => {
    if (wsRefresh > 0 && isSilver) {
      // The WebSocket will automatically reconnect when the context value changes
      console.log("WebSocket refresh triggered");
    }
  }, [wsRefresh, isSilver]);
  
  // Added console logs for debugging
  console.log("Banking component rendering with:", {
    userEmail,
    userType,
    companies,
    wsStatus,
    selectedCompany,
  });

  if (auth.isLoading) return <div>Loading user info...</div>;

  if (!auth.isAuthenticated) return <Navigate to="/" />;

  if (shouldShowReconnect) {
    return (
      <div className="Banking-container">
        <Sidebar />
        <div className="Banking-main">
          <h2>Please ensure your Tally Connector is running</h2>
          <p>We are trying to connect via WebSocket. Please make sure Tally Connector is on.</p>
          <p>Current connection status: {wsStatus}</p>
          <button
            onClick={() => setWsRefresh((prev) => prev + 1)}
            style={{
              padding: "10px 20px",
              backgroundColor: "#4CAF50",
              color: "white",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
          >
            Retry Connection
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="Banking-container">
        <Sidebar />
        <div className="Banking-main">
          <h2>Loading companies...</h2>
        </div>
      </div>
    );
  }

  if (!selectedCompany) {
    return (
      <div className="Banking-container">
        <Sidebar />
        <div className="Banking-main">
          <div className="no-company-message">
            <h2>No Company Selected</h2>
            <p>Please select a company from the dropdown in the top navigation bar.</p>
            <p>Available companies:</p>
            <ul>
              {companies.map((company) => (
                <li key={company.company_id}>{company.company_name}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="Banking-container">
      <Sidebar />
      <div className="Banking-main">
        <NavbarWithCompany lockCompany={true} />
        <ExcelUpload userEmail={userEmail} selectedCompany={selectedCompany} />
      </div>
    </div>
  );
}

export default Banking;
