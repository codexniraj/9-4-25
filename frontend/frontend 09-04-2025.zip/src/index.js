// src/index.js
import React, { useEffect } from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { AuthProvider } from "react-oidc-context";
import App from "./App";
import { WebSocketProvider } from "./context/WebSocketProvider";
import { CompanyProvider } from "./context/CompanyContext";

// Auth cleanup utility wrapper
const AuthCleanupWrapper = ({ children }) => {
  useEffect(() => {
    // Check for ?logout=true in URL - indicates post-logout
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('logout') && urlParams.get('logout') === 'true') {
      console.log("Post-logout cleanup initiated");
      
      // Clear all auth-related storage
      localStorage.removeItem("oidc.user:https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_lCMCna2RL:7mdvqnncbbn2s8m668ip9jus5o");
      sessionStorage.removeItem("oidc.user:https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_lCMCna2RL:7mdvqnncbbn2s8m668ip9jus5o");
      
      // Clean URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }
    
    // Check if there's an auth token but it's expired or invalid
    const authKey = "oidc.user:https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_lCMCna2RL:7mdvqnncbbn2s8m668ip9jus5o";
    const userData = localStorage.getItem(authKey);
    
    if (userData) {
      try {
        const parsedData = JSON.parse(userData);
        // Check if token is expired
        if (parsedData.expires_at && parsedData.expires_at < Date.now() / 1000) {
          console.log("Found expired token, clearing");
          localStorage.removeItem(authKey);
          sessionStorage.removeItem(authKey);
        }
      } catch (e) {
        console.error("Error checking token expiry:", e);
        // If there's any error parsing, remove the data
        localStorage.removeItem(authKey);
        sessionStorage.removeItem(authKey);
      }
    }
  }, []);
  
  return children;
};

const cognitoConfig = {
  authority: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_lCMCna2RL",
  client_id: "7mdvqnncbbn2s8m668ip9jus5o",
  redirect_uri: "http://localhost:3000",
  response_type: "code",
  scope: "email openid phone",
};

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <AuthCleanupWrapper>
      <AuthProvider {...cognitoConfig}>
        <WebSocketProvider>
          <CompanyProvider>
            <BrowserRouter>
              <App />
            </BrowserRouter>
          </CompanyProvider>
        </WebSocketProvider>
      </AuthProvider>
    </AuthCleanupWrapper>
  </React.StrictMode>
);
