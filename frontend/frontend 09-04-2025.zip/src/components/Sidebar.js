import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Sidebar.css';

const Sidebar = () => {
  const [bulkOpen, setBulkOpen] = useState(false);

  const toggleBulkUpload = () => {
    setBulkOpen(!bulkOpen);
  };

  return (
    <div className="sidebar">
      <ul>
        <li><Link to="/home">Dashboard</Link></li>
        <li className="submenu">
          <span onClick={toggleBulkUpload} className="submenu-title">
            Bulk Upload {bulkOpen ? '▾' : '▸'}
          </span>
          {bulkOpen && (
            <ul className="submenu-items">
              <li><Link to="/bulk-upload/banking">Banking</Link></li>
              <li><Link to="/bulk-upload/journal">Journal</Link></li>
              <li><Link to="/bulk-upload/sales">Sales</Link></li>
              <li><Link to="/bulk-upload/sales-return">Sales-Return</Link></li>
              <li><Link to="/bulk-upload/purchase">Purchase</Link></li>
              <li><Link to="/bulk-upload/purchase-return">Purchase-Return</Link></li>
              <li><Link to="/bulk-upload/Ledger">Ledger</Link></li>
              <li><Link to="/bulk-upload/items">Items</Link></li>
            </ul>
          )}
        </li>
        <li><a href="#">Profile Update</a></li>
        <li><a href="#">Add Child User</a></li>
        <li><a href="#">Settings</a></li>
        <li><a href="#">Support</a></li>
      </ul>
    </div>
  );
};

export default Sidebar;
