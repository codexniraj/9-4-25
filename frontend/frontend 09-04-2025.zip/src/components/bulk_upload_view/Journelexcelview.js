import React, { useEffect, useState } from 'react';
import './Journelexcelview.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import AddLedgerButton from './AddLedgerbutton';
import NavbarWithCompany from '../NavbarWithCompany';

function Journelexcelview() {
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [filterText, setFilterText] = useState('');
  const [tempTable, setTempTable] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [ledgerOptions, setLedgerOptions] = useState([]);
  const [invalidLedgers, setInvalidLedgers] = useState([]);
  const [selectedCompany, setSelectedCompany] = useState('');
  const [currentCompany, setCurrentCompany] = useState('');
  const [selectedRows, setSelectedRows] = useState([]);

  const [selectAll, setSelectAll] = useState(false);
  const [costCenterOptions, setCostCenterOptions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState({ rowIndex: null, column: null });
  const [inputStates, setInputStates] = useState({});

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedRows([]);
    } else {
      const allIndexes = filteredData.map((_, index) => index);
      setSelectedRows(allIndexes);
    }
    setSelectAll(!selectAll);
  };

  useEffect(() => {
    const company = sessionStorage.getItem("selectedCompany");
    if (company) {
      setCurrentCompany(company);
      setSelectedCompany(company);
      fetchLedgerNames();
    }
  }, []);

  useEffect(() => {
    const loadLatestData = async () => {
      try {
        const email = sessionStorage.getItem("userEmail");
        const company = sessionStorage.getItem("selectedCompany");
        
        if (!email || !company) {
          setError("Missing user email or company");
          return;
        }

        // First try to get the table from sessionStorage
        const sessionTable = sessionStorage.getItem('tempTable');
        console.log("Loading table from session:", sessionTable);
        
        if (sessionTable) {
          // If we have a table in sessionStorage, use it
          setTempTable(sessionTable);
          await fetchData(sessionTable);
        } else {
          // If no table in sessionStorage, get the latest from API
          const uploadRes = await axios.get('http://localhost:3001/api/getUserJournelUploads', {
            params: { email, company }
          });

          if (uploadRes.data && uploadRes.data.length > 0) {
            const latestTable = uploadRes.data[0].temp_table;
            setTempTable(latestTable);
            await fetchData(latestTable);
          } else {
            setError("No journal data found");
          }
        }
      } catch (err) {
        console.error('Error loading latest data:', err);
        setError('Failed to load latest data');
      }
    };

    loadLatestData();
  }, []);

  useEffect(() => {
    if (filterText.trim() === '') {
      setFilteredData(data);
    } else {
      const lower = filterText.toLowerCase();
      const result = data.filter(row =>
        Object.values(row).some(val =>
          val && val.toString().toLowerCase().includes(lower)
        )
      );
      setFilteredData(result);
    }
  }, [filterText, data]);

  const fetchData = async (tableName) => {
    if (!tableName) {
      console.error('No table name provided to fetchData');
      setError('No table name provided');
      return;
    }
  
    try {
      const timestamp = Date.now(); // Prevent browser caching
  
      const res = await axios.get('http://localhost:3001/api/getJournalData', {
        params: { tempTable: tableName, t: timestamp },
      });
  
      if (res.data && Array.isArray(res.data)) {
        console.log('Frontend fetched rows:', res.data);
  
        if (res.data.length === 0) {
          console.warn('No rows returned from backend');
          setError('No data available');
          return;
        }
  
        if (!('id' in res.data[0])) {
          console.error('Fetched data missing ID:', res.data[0]);
          setError('Fetched data missing ID');
          return;
        }
  
        setData(res.data);
        setFilteredData(res.data);
        setTempTable(tableName);
        sessionStorage.setItem('tempTable', tableName);
  
        const uploadMeta = JSON.parse(sessionStorage.getItem('uploadMeta')) || {};
        setInvalidLedgers(uploadMeta.invalidLedgers || []);
      } else {
        console.error('Invalid data format received:', res.data);
        setError('Invalid data format received from server');
      }
    } catch (err) {
      console.error('Error fetching data:', err);
      setError('Failed to load data: ' + (err.response?.data?.error || err.message));
    }
  };

  const fetchLedgerNames = async () => {
    const currentCompany = sessionStorage.getItem("selectedCompany");
    const email = sessionStorage.getItem("userEmail");
  
    if (!currentCompany || !email) {
      console.error("Missing email or company for ledger fetch.");
      return;
    }
  
    try {
      const res = await axios.get("http://localhost:3001/api/getMergedLedgerNames", {
        params: { email, company: currentCompany },
      });
  
      console.log("Merged Ledger Names:", res.data);
      setLedgerOptions(res.data);
    } catch (err) {
      console.error("Error fetching merged ledger names:", err);
    }
  };
  

  const handleRowSelect = (rowIndex) => {
    const selectedRef = data[rowIndex]?.reference_no;
    if (!selectedRef) return;

    const relatedIndexes = data
      .map((row, i) => (row.reference_no === selectedRef ? i : null))
      .filter(i => i !== null);

    setSelectedRows(prev => {
      const allSelected = relatedIndexes.every(i => prev.includes(i));
      if (allSelected) {
        return prev.filter(i => !relatedIndexes.includes(i));
      } else {
        return Array.from(new Set([...prev, ...relatedIndexes]));
      }
    });
  };

  const isRowSelected = (rowIndex) => selectedRows.includes(rowIndex);

  const handleSave = async () => {
    if (selectedRows.length === 0) {
      setError("Please select at least one row to save.");
      return;
    }

    const rowsToValidate = selectedRows.map(i => data[i]);
    const hasInvalid = rowsToValidate.some(row => 
      !ledgerOptions.some(option => 
        option.toLowerCase() === row.particulars?.toLowerCase()?.trim()
      )
    );
    if (hasInvalid) {
      setError("Please resolve all red-marked ledgers before saving.");
      return;
    }

    let debit = 0, credit = 0;
    for (let row of rowsToValidate) {
      if (row.dr_cr === "Dr") debit += Number(row.amount || 0);
      else if (row.dr_cr === "Cr") credit += Number(row.amount || 0);
    }

    if (debit !== credit) {
      setError(`Dr/Cr mismatch: Debit = ${debit}, Credit = ${credit}`);
      return;
    }

    try {
      const email = sessionStorage.getItem("userEmail");
      const company = sessionStorage.getItem("selectedCompany");
      
      if (!email || !company) {
        setError("Missing user email or company");
        return;
      }

      // Get the current tempTable from state or sessionStorage
      let currentTempTable = tempTable || sessionStorage.getItem('tempTable');
      
      if (!currentTempTable) {
        const uploadRes = await axios.get('http://localhost:3001/api/getUserJournelUploads', {
          params: { email, company }
        });
        if (uploadRes.data && uploadRes.data.length > 0) {
          currentTempTable = uploadRes.data[0].temp_table;
          setTempTable(currentTempTable);
          sessionStorage.setItem('tempTable', currentTempTable);
        } else {
          setError("No temporary table found");
          return;
        }
      }

      // Now save each selected row
      for (let rowIndex of selectedRows) {
        const rowData = data[rowIndex];
        if (!rowData.id) {
          console.error(`Row at index ${rowIndex} missing id:`, rowData);
          continue;
        }

        const payload = {
          tempTable: currentTempTable,
          creation_id: rowData.id,
          email,
          company,
          updatedRow: {
            journal_no: rowData.journal_no,
            reference_no: rowData.reference_no,
            date: rowData.date,
            cost_center: rowData.cost_center,
            particulars: rowData.particulars,
            name_of_item: rowData.name_of_item,
            quantity: rowData.quantity,
            rate: rowData.rate,
            dr_cr: rowData.dr_cr,
            amount: rowData.amount,
            ledger_narration: rowData.ledger_narration,
            narration: rowData.narration
          }
        };

        console.log('Saving row with payload:', payload);
        
        await axios.post("http://localhost:3001/api/updateJournalRow", payload);
      }
      
      // After successful save, refresh the data
      await refreshData();
      
      setMessage("Selected rows saved successfully.");
      setError('');
    } catch (err) {
      console.error("Save error:", err);
      setError("Save failed: " + (err.response?.data?.error || err.message));
      if (err.response?.data?.details) {
        console.error("Error details:", err.response.data.details);
      }
    }
  };

  const handleSendToTally = async () => {
    // Use the same validation function we use elsewhere
    const hasInvalidLedgers = filteredData.some(row => 
      !isValidLedgerName(row.particulars, ledgerOptions)
    );

    if (hasInvalidLedgers) {
      setError("Cannot send to Tally: unresolved ledgers.");
      return;
    }

    try {
      const res = await axios.post('http://localhost:3001/api/sendJournalToTally', {
        company: currentCompany,
        tempTable: tempTable
      });
      setMessage(res.data.message || "Data sent to Tally successfully.");
    } catch (err) {
      setError("TallyConnector is offline or failed to receive data.");
    }
  };

  const formatDate = (value) => {
    if (!value) return '';
    if (typeof value === 'number') {
      const jsDate = new Date((value - 25569) * 86400 * 1000);
      return jsDate.toISOString().split('T')[0];
    }
    const parsed = new Date(value);
    if (!isNaN(parsed.getTime())) {
      return parsed.toISOString().split('T')[0];
    }
    return '';
  };

  const handleCellChange = (rowIndex, key, value) => {
    setData(prevData => {
      const updated = [...prevData];
      updated[rowIndex] = { ...updated[rowIndex], [key]: value };
      return updated;
    });
  };

  // Add this function to handle suggestions display
  const handleInputFocus = (rowIndex, column) => {
    setShowSuggestions({ rowIndex, column });
  };

  // Modify the validation function
  const isValidLedgerName = (value, options) => {
    if (!value) return true; // Empty value is considered valid while typing
    return options.some(option => 
      option.toLowerCase() === value.toLowerCase()?.trim()
    );
  };

  // Add this function to handle input change
  const handleInputChange = (rowIndex, key, value) => {
    // Mark the field as being edited
    setInputStates(prev => ({
      ...prev,
      [`${rowIndex}-${key}`]: { isEditing: true }
    }));
    
    handleCellChange(rowIndex, key, value);
  };

  // Modify the blur handler
  const handleInputBlur = (rowIndex, key, value) => {
    setTimeout(() => {
      setShowSuggestions({ rowIndex: null, column: null });
      
      // Mark the field as no longer being edited
      setInputStates(prev => ({
        ...prev,
        [`${rowIndex}-${key}`]: { isEditing: false }
      }));
    }, 200);
  };

  // Add this function to check if field is being edited
  const isFieldEditing = (rowIndex, key) => {
    return inputStates[`${rowIndex}-${key}`]?.isEditing;
  };

  // Add this function to filter suggestions
  const getFilteredSuggestions = (value, options) => {
    const inputValue = value?.toLowerCase()?.trim() || '';
    return options.filter(option => 
      option.toLowerCase().includes(inputValue)
    );
  };

  // Modify the refreshData function
  const refreshData = async () => {
    try {
      const email = sessionStorage.getItem("userEmail");
      const company = sessionStorage.getItem("selectedCompany");
      
      if (!email || !company) {
        setError("Missing user email or company");
        return;
      }

      // Get the current table from sessionStorage
      const currentTable = sessionStorage.getItem('tempTable');
      console.log("Refreshing data for table:", currentTable);

      if (currentTable) {
        // Fetch the latest data with a timestamp to prevent caching
        const timestamp = new Date().getTime();
        const res = await axios.get('http://localhost:3001/api/getJournalData', {
          params: { 
            tempTable: currentTable,
            _t: timestamp // Add timestamp to prevent caching
          }
        });
        
        if (res.data && Array.isArray(res.data)) {
          setData(res.data);
          setFilteredData(res.data);
          setTempTable(currentTable);
          console.log('Refreshed data:', res.data);
        } else {
          console.error('Invalid data format received:', res.data);
          setError('Invalid data format received from server');
        }
      } else {
        setError("No temporary table found in session storage");
      }
    } catch (err) {
      console.error('Error refreshing data:', err);
      setError('Failed to refresh data: ' + (err.response?.data?.error || err.message));
    }
  };

  return (
    <div className="excelview-wrapper container-fluid p-4">
      <NavbarWithCompany selectedCompany={selectedCompany} setSelectedCompany={setSelectedCompany} lockCompany={true} />
      <h2 className="mb-4 text-center">Journal Excel Data Review</h2>

      <div className="action-buttons d-flex justify-content-center gap-3 mb-4">
        <button className="btn btn-success" onClick={handleSave}>Save</button>
        <button className="btn btn-warning" onClick={handleSendToTally}>Send To Tally</button>
        <AddLedgerButton onAdd={(newLedger) => setLedgerOptions([...ledgerOptions, newLedger])} />
      </div>

      <div className="filter-section mb-3 text-center">
        <input
          type="text"
          className="form-control w-50 mx-auto"
          placeholder="Filter by any field..."
          value={filterText}
          onChange={(e) => setFilterText(e.target.value)}
        />
      </div>

      {error && <div className="alert alert-danger">{error}</div>}
      {message && <div className="alert alert-success">{message}</div>}

      <div className="table-responsive">
        <table className="table table-bordered table-sm table-striped">
          <thead className="table-dark">
            <tr>
              <th><input type="checkbox" checked={selectAll} onChange={handleSelectAll} /></th>
              <th>Sr. No.</th>
              {filteredData[0] && Object.keys(filteredData[0]).map((key) => (
                <th key={key}>{key.replace(/_/g, ' ')}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filteredData.map((row, rowIndex) => (
              <tr key={rowIndex}>
                <td>
                  <input type="checkbox" checked={isRowSelected(rowIndex)} onChange={() => handleRowSelect(rowIndex)} />
                </td>
                <td>{rowIndex + 1}</td>
                {Object.entries(row).map(([key, val], colIndex) => {
                  const lowerKey = key.toLowerCase();
                  const isLedger = lowerKey === 'particulars';
                  const isCostCenter = lowerKey === 'cost_center';
                  const isDate = lowerKey === 'date';
                  const isDrCr = lowerKey === 'dr_cr';
                  
                  // Only show validation error if not editing and value is invalid
                  const isEditing = isFieldEditing(rowIndex, key);
                  const showValidationError = isLedger && !isEditing && !isValidLedgerName(val, ledgerOptions);

                  if (isLedger || isCostCenter) {
                    const options = isLedger ? ledgerOptions : costCenterOptions;
                    const showDropdown = showSuggestions.rowIndex === rowIndex && 
                                       showSuggestions.column === key;
                    const suggestions = getFilteredSuggestions(val, options);

                    return (
                      <td key={colIndex} className={showValidationError ? 'bg-danger text-white' : ''}>
                        <div className="position-relative">
                          <input
                            type="text"
                            className={`form-control form-control-sm ${showValidationError ? 'border-danger' : ''}`}
                            value={val || ''}
                            onChange={(e) => handleInputChange(rowIndex, key, e.target.value)}
                            onFocus={() => handleInputFocus(rowIndex, key)}
                            onBlur={() => handleInputBlur(rowIndex, key, val)}
                            placeholder={isLedger ? "Type to search ledger..." : "Type to search cost center..."}
                          />
                          {showDropdown && suggestions.length > 0 && val && (
                            <div className="suggestions-dropdown">
                              {suggestions.map((suggestion, idx) => (
                                <div
                                  key={idx}
                                  className="suggestion-item"
                                  onMouseDown={() => handleCellChange(rowIndex, key, suggestion)}
                                >
                                  {suggestion}
                                </div>
                              ))}
                            </div>
                          )}
                          {showValidationError && (
                            <span className="ms-2 text-danger" title="Add Ledger" style={{ cursor: 'pointer' }}>ℹ️</span>
                          )}
                        </div>
                      </td>
                    );
                  }

                  return (
                    <td key={colIndex}>
                      {isDate ? (
                        <input type="date" className="form-control form-control-sm" value={formatDate(val)} onChange={(e) => handleCellChange(rowIndex, key, e.target.value)} />
                      ) : isDrCr ? (
                        <select className="form-select form-select-sm" value={val} onChange={(e) => handleCellChange(rowIndex, key, e.target.value)}>
                          <option value="">Select</option>
                          <option value="Dr">Dr</option>
                          <option value="Cr">Cr</option>
                        </select>
                      ) : (
                        <input type="text" value={val || ''} onChange={(e) => handleCellChange(rowIndex, key, e.target.value)} className="form-control form-control-sm" />
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Journelexcelview;
