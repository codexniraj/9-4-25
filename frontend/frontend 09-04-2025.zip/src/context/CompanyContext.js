import React, { createContext, useState, useContext, useEffect } from 'react';
import useUser from '../hooks/useUser';
import { useUserType } from '../hooks/useUserType';
import useCompanies from '../hooks/useCompanies';

// Create the context
const CompanyContext = createContext();

// Create a custom hook to use the company context
export const useCompanyContext = () => {
  const context = useContext(CompanyContext);
  if (!context) {
    throw new Error('useCompanyContext must be used within a CompanyProvider');
  }
  return context;
};

// Provider component to wrap around the app
export const CompanyProvider = ({ children }) => {
  const [selectedCompany, setSelectedCompany] = useState('');
  const { userEmail } = useUser();
  const userType = useUserType();
  const { companies, loading } = useCompanies(userEmail, userType);

  // Debug logging
  useEffect(() => {
    console.log("CompanyProvider - userType:", userType);
    console.log("CompanyProvider - userEmail:", userEmail);
  }, [userType, userEmail]);

  // For testing, we can manually set a user type
  useEffect(() => {
    // Only set this if you want to override the user type for testing
    // Uncomment the next line to test with a specific user type
    // sessionStorage.setItem('userType', 'gold');  
  }, []);

  // Load selectedCompany from sessionStorage on initial render
  useEffect(() => {
    const storedCompany = sessionStorage.getItem('selectedCompany');
    if (storedCompany) {
      setSelectedCompany(storedCompany);
    }
  }, []);

  // Handle company selection
  const handleCompanyChange = (companyId) => {
    setSelectedCompany(companyId);
    sessionStorage.setItem('selectedCompany', companyId);
  };

  // Get the company name based on selected ID
  const companyName = companies.find(c => c.company_id === selectedCompany)?.company_name || '';

  // Value to be provided by the context
  const contextValue = {
    selectedCompany,
    setSelectedCompany: handleCompanyChange,
    companyName,
    companies,
    loading,
    userType  // Add userType to the context so it's accessible elsewhere
  };

  return (
    <CompanyContext.Provider value={contextValue}>
      {children}
    </CompanyContext.Provider>
  );
}; 