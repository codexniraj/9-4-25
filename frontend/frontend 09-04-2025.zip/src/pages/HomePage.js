// src/components/HomePage.js
import React from "react";
import { Link, Navigate } from "react-router-dom";
import { useAuth } from "react-oidc-context";
import { useUserType } from "../hooks/useUserType";
import "./HomePage.css";

const HomePage = () => {
  const auth = useAuth();
  const userType = useUserType();
  console.log("HomePage - auth:", auth);
  console.log("HomePage - userType:", userType);

  if (auth.isLoading) {
    return <div>Loading...</div>;
  }

  // if (!auth.isAuthenticated) {
  //   return <Navigate to="/" />;
  // }

  if (userType === "gold") {
    return <Navigate to="/home" />;
  }

  return (
    <div className="home-page">
      <nav className="navbar">
        <div className="nav-logo">TallyFy</div>
        <ul className="nav-links">
          <li>
            <Link to="/pricing">Pricing</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/features">Features</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
        <div className="nav-button-container">
          {auth.isAuthenticated ? (
            <button
              className={`dashboard-btn ${userType === null ? "disabled" : ""}`}
              onClick={() => {
                if (userType) {
                  window.location.href = "/home";
                }
              }}
              title={userType === null ? "Upgrade to Gold" : ""}
              disabled={userType === null}
            >
              Dashboard
            </button>
          ) : (
            <button className="login-btn" onClick={() => auth.signinRedirect()}>
              Log In with AWS Cognito
            </button>
          )}
        </div>
      </nav>
      <header className="hero-section">
        <h1>Welcome to TallyFy</h1>
        <p>
          Your one-stop solution for managing software updates, licenses, and system configurations.
        </p>
      </header>
      <section className="pricing-section" id="pricing">
        <h2>Pricing</h2>
        <div className="pricing-cards">
          <div className="pricing-card">
            <h3>Silver</h3>
            <p>$9.99/month</p>
            <p>Local Storage Only</p>
            <button>Buy Now</button>
          </div>
          <div className="pricing-card">
            <h3>Gold</h3>
            <p>$19.99/month</p>
            <p>Cloud Storage + Multi-User</p>
            <button>Buy Now</button>
          </div>
        </div>
      </section>
      <section className="about-section" id="about">
        <h2>About TallyFy</h2>
        <p>
          TallyFy is designed to help you manage your software lifecycle seamlessly. Whether you’re managing updates or handling licenses, our platform ensures a smooth experience.
        </p>
      </section>
      <footer className="footer">
        <p>&copy; {new Date().getFullYear()} TallyFy. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default HomePage;
