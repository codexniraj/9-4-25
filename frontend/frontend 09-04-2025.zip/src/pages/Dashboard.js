import React from "react";
import { useAuth } from "react-oidc-context";
import { Navigate, useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import "./Dashboard.css";

// Import images
import logo from "./logo.jpg";
import dataEntryIcon from "./data-entry-icon.png";
import emailIcon from "./email-icon.png";
import phoneIcon from "./phone-icon.jpg";
import faqIcon from "./faq-icon.png";

function Dashboard() {
  const auth = useAuth();
  const navigate = useNavigate();

  if (auth.isLoading) {
    return <div>Loading user info...</div>;
  }

  if (!auth.isAuthenticated) {
    return <Navigate to="/" />;
  }

  const handleExploreClick = () => {
    navigate('ExcelUpload');
  };

  return (
    <div className="dashboard-container">
      <Sidebar />
      <div className="dashboard-main">
        <header className="dashboard-header">
          <div className="logo-section">
            <img src={logo} alt="Tallyfy.AI" className="logo" />
            <h1>Welcome to Tallyfy.AI</h1>
          </div>
          <div className="header-actions">
            <button className="notification-btn">
              <i className="fas fa-bell"></i>
            </button>
            <button className="settings-btn">
              <i className="fas fa-cog"></i>
            </button>
            <button className="profile-btn">
              <i className="fas fa-user"></i>
            </button>
          </div>
        </header>

        <main className="dashboard-content">
          <section className="feature-card active">
            <div className="card-icon">
              <img src={dataEntryIcon} alt="Data Entry" />
            </div>
            <h2>Data Entry Automation</h2>
            <p>Simplify your workflow, amplify accuracy, and save time effortlessly!</p>
            <button className="explore-btn" onClick={handleExploreClick}>Explore Now</button>
          </section>
          <div className="contact-section">
            <div className="contact-card">
              <img src={emailIcon} alt="Email" />
              <h3>Reach Us Anytime via Email</h3>
              <p>Got a question? Shoot us an email at <a href="mailto:support@tallyfy.ai">support@tallyfy.ai</a> and we'll help you out.</p>
            </div>

            <div className="contact-card">
              <img src={phoneIcon} alt="Phone" />
              <h3>Call for Quick Support</h3>
              <p>Need help right away? Give us a call at <a href="tel:+918888888888">+91 8888888888</a> and we'll sort it out.</p>
            </div>

            <div className="contact-card">
              <img src={faqIcon} alt="FAQ" />
              <h3>FAQs at Your Fingertips</h3>
              <p>Find answers to common questions in our FAQ section. <a href="/faq">Read More</a></p>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default Dashboard;
