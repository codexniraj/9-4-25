import { useState, useEffect } from "react";
import axios from "axios";
import { useWebSocketContext } from "../context/WebSocketProvider";


function useCompanies(userEmail, userTypeObj) {
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Handle userType as either string or object from useUserType
  const userType = typeof userTypeObj === 'object' && userTypeObj !== null 
    ? userTypeObj.userType 
    : userTypeObj;
    
  // Initialize WebSocket only for silver users
  const { wsStatus, companies: wsCompanies, fetchCompanies } = useWebSocketContext() || {
    wsStatus: "Disconnected",
    companies: [],
    fetchCompanies: () => console.warn("WebSocketContext not available"),
  };

  useEffect(() => {
    if (!userEmail) return;
    setLoading(true);

    if (userType === "silver") {
      // For silver users, use the WebSocket
      if (wsStatus === "Connected") {
        fetchCompanies(userEmail);
      }
      if (wsCompanies && wsCompanies.length > 0) {
        setCompanies(wsCompanies);
      }
      setLoading(false);
    } else if (userType === "trial") {
      // For trial users, use the HTTP endpoint with limitations (e.g., a limit parameter)
      const fetchCompaniesTrial = async () => {
        try {
          // Assume the backend checks the "trial" flag and limits the data accordingly
          const url = `/api/getUserCompanies?email=${userEmail}&limit=10`;
          const response = await axios.get(url);
          setCompanies(response.data);
        } catch (error) {
          console.error("Error fetching companies for trial user:", error);
        } finally {
          setLoading(false);
        }
      };
      fetchCompaniesTrial();
    } else {
      // For gold or other full-access users
      const fetchCompaniesHttp = async () => {
        try {
          const url = `/api/getUserCompanies?email=${userEmail}`;
          const response = await axios.get(url);
          setCompanies(response.data);
        } catch (error) {
          console.error("Error fetching companies:", error);
        } finally {
          setLoading(false);
        }
      };
      fetchCompaniesHttp();
    }
  }, [userEmail, userType, wsStatus, wsCompanies, fetchCompanies]);

  return { companies, loading, wsStatus };
}

export default useCompanies;
