import { useState, useEffect, useCallback, useRef } from "react";

export default function useWebSocket(url) {
  const [wsStatus, setWsStatus] = useState("Connecting...");
  const [pdfStatus, setPdfStatus] = useState("");
  const [companies, setCompanies] = useState([]);
  const [tempTables, setTempTables] = useState([]);
  const [tempTableData, setTempTableData] = useState([]);
  const [bankAccounts, setBankAccounts] = useState([]);
  const [ledgerOptions, setLedgerOptions] = useState([]);

  const wsRef = useRef(null);

  const connectWebSocket = useCallback(() => {
    if (
      wsRef.current?.readyState === WebSocket.OPEN ||
      wsRef.current?.readyState === WebSocket.CONNECTING
    ) {
      return;
    }
    try {
      const ws = new WebSocket(url);
      wsRef.current = ws;
      ws.retryCount = 0;
      let lastHeartbeat = Date.now();

      ws.onopen = () => {
        setWsStatus("Connected");
        lastHeartbeat = Date.now();
      };

      ws.onclose = (event) => {
        setWsStatus("Disconnected");
        if (
          event.code !== 1000 &&
          event.code !== 1001 &&
          Date.now() - lastHeartbeat > 30000
        ) {
          const timeout = Math.min(1000 * Math.pow(1.5, ws.retryCount || 0), 30000);
          setTimeout(() => {
            if (wsRef.current === ws) {
              ws.retryCount = (ws.retryCount || 0) + 1;
              connectWebSocket();
            }
          }, timeout);
        }
      };

      ws.onerror = () => {
        setWsStatus("Error connecting");
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          switch (data.type) {
            case "heartbeat":
              lastHeartbeat = Date.now();
              ws.send(JSON.stringify({ type: "pong" }));
              break;
            case "pong":
              lastHeartbeat = Date.now();
              break;
            case "connection":
              if (data.status === "connected") {
                setWsStatus("Connected");
                ws.retryCount = 0;
                lastHeartbeat = Date.now();
              }
              break;
            case "process_complete":
              setPdfStatus(`Processing completed: ${data.filename}`);
              break;
            case "process_error":
              setPdfStatus(`Error: ${data.error}`);
              break;
            case "error":
              setPdfStatus(`Server error: ${data.error}`);
              break;
            case "companies_data":
              // Handle the companies data received from the server.
              setCompanies(data.data);
              break;
            case "temp_tables_data":
              console.log("Received temp_tables_data:", data.data);
              setTempTables(data.data);
              break;
            case "temp_table_data":
              console.log("Temp table data received:", data);
              setTempTableData(data.data);
              break;
            case "bank_names_data":
              console.log("Bank names data received:", data.data);
              setBankAccounts(data.data || []);
              break;
            case "ledger_options":
              console.log("Ledger options received:", data.options);
              setLedgerOptions(data.options);
              break;
            default:
              break;
          }
        } catch (error) {
          console.error("Error parsing WebSocket message:", error);
        }
      };
    } catch (error) {
      setWsStatus("Error connecting");
    }
  }, [url]);

  useEffect(() => {
    const timer = setTimeout(() => {
      connectWebSocket();
    }, 500);

    const pingInterval = setInterval(() => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: "ping" }));
      }
    }, 120000);

    const statusChecker = setInterval(() => {
      if (
        wsRef.current?.readyState === WebSocket.CLOSED ||
        wsRef.current?.readyState === WebSocket.CLOSING
      ) {
        connectWebSocket();
      }
    }, 10000);

    return () => {
      clearTimeout(timer);
      clearInterval(pingInterval);
      clearInterval(statusChecker);
      if (wsRef.current) {
        wsRef.current.close(1000, "Component unmounting");
      }
    };
  }, [connectWebSocket]);

  const sendData = useCallback((data) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(data);
    }
  }, []);

  // Function to request companies from the local DB via WebSocket
  const fetchCompanies = useCallback((userEmail) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      const requestData = {
        type: "fetch_companies",
        user_email: userEmail
      };
      wsRef.current.send(JSON.stringify(requestData));
    } else {
      console.error("WebSocket is not open. Cannot fetch companies.");
    }
  }, []);

  // Function to request temporary tables via WebSocket for silver users
  const fetchTempTables = useCallback((userEmail, company) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      const requestData = {
        type: "fetch_temp_tables",
        user_email: userEmail,
        company: company,
      };
      wsRef.current.send(JSON.stringify(requestData));
    } else {
      console.error("WebSocket is not open. Cannot fetch temporary tables.");
    }
  }, []);

  const fetchTempTableData = useCallback((uploadId) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: "fetch_temp_table_data",
        upload_id: uploadId
      }));
    }
  }, []);

  const sendUpdateMessage = useCallback((tempTable, updatedData) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      const message = {
        type: "update_temp_excel",
        tempTable,
        data: updatedData,
      };
      wsRef.current.send(JSON.stringify(message));
    } else {
      console.error("WebSocket is not open. Cannot send update message.");
    }
  }, []);

  const sendToTallyMessage = useCallback((company, tempTable, selectedTransactions) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      const message = {
        type: "send_to_tally",
        company,
        tempTable,
        selectedTransactions: selectedTransactions && selectedTransactions.length > 0 ? selectedTransactions : null,
      };
      wsRef.current.send(JSON.stringify(message));
    } else {
      console.error("WebSocket is not open. Cannot send tally message.");
    }
  }, []);

  const fetchBank = useCallback((company_id, user_email) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      const message = {
        type: "fetch_bank_names",
        company_id,
        user_email,
      };
      wsRef.current.send(JSON.stringify(message));
    } else {
      console.error("WebSocket is not open. Cannot fetch bank accounts.");
    }
  }, []);
  
  const fetchLedgerOptions = useCallback((company_id) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      const requestData = {
        type: "fetch_ledger_options",
        company_id,
      };
      wsRef.current.send(JSON.stringify(requestData));
    } else {
      console.error("WebSocket is not open. Cannot fetch ledger options.");
    }
  }, []);
  
  

  return { wsStatus, pdfStatus, bankAccounts, ledgerOptions, tempTables, companies, tempTableData, fetchBank, fetchLedgerOptions, sendToTallyMessage, sendUpdateMessage, fetchTempTableData, sendData, fetchCompanies, fetchTempTables, wsRef };
  
}
