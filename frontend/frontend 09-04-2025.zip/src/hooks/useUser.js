import { useAuth } from "react-oidc-context";
import { useEffect } from "react";

function useUser() {
  const auth = useAuth();
  const userEmail = auth?.user?.profile?.email;

  useEffect(() => {
    if (userEmail) {
      sessionStorage.setItem("userEmail", userEmail);
    }
  }, [userEmail]);

  return { userEmail };
}

export default useUser;
