import { useAuth } from "react-oidc-context";

/**
 * Custom hook to handle logout functionality
 * Ensures thorough cleaning of all authentication data
 */
const useLogout = () => {
  const auth = useAuth();

  /**
   * Performs a complete logout by:
   * 1. Clearing all browser storage (session, local, cookies)
   * 2. Removing the user from OIDC context if possible
   * 3. Redirecting to home page
   */
  const logout = () => {
    try {
      console.log("Starting logout process...");
      
      // Force removal of all items from storage
      localStorage.clear();
      sessionStorage.clear();
      
      // Clear cookies by setting expiration in the past
      document.cookie.split(";").forEach(cookie => {
        const eqPos = cookie.indexOf("=");
        const name = eqPos > -1 ? cookie.substring(0, eqPos).trim() : cookie.trim();
        document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`;
      });
      
      // If using react-oidc-context, remove the user
      if (auth && typeof auth.removeUser === 'function') {
        console.log("Removing user from auth context...");
        auth.removeUser();
        window.location.href = '/';
      }

      // Use the signoutRedirect method if authenticated
      if (auth && auth.isAuthenticated) {
        console.log("Using auth.signoutRedirect()");
        auth.signoutRedirect()
          .then(() => {
            console.log("Signout redirect initiated");
            window.location.href = '/';
          })
          .catch(err => {
            console.error("Error during signout redirect:", err);
            // Fallback to direct redirect
            window.location.href = '/';
          });
      } else {
        // Direct redirect if not authenticated or auth not available
        console.log("Redirecting to home");
        window.location.href = '/';
      }
    } catch (error) {
      console.error("Logout error:", error);
      
      // Fallback - just redirect to home
      window.location.href = '/';
    }
  };

  return { logout };
};

export default useLogout; 