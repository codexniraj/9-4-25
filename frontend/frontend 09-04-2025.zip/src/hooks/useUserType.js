// src/hooks/useUserType.js

import { useAuth } from "react-oidc-context";
import { useEffect, useState } from "react";

export const useUserType = () => {
  const auth = useAuth();
  // Initialize as null but provide proper loading state
  const [userType, setUserType] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    console.log("useUserType - auth status:", {
      isAuthenticated: auth.isAuthenticated,
      isLoading: auth.isLoading,
      user: auth.user
    });

    try {
      // First check session storage for manually set user type (for development)
      const storedType = sessionStorage.getItem("userType");
      
      if (storedType && ["gold", "silver", "trial"].includes(storedType)) {
        console.log("Using stored user type from sessionStorage:", storedType);
        setUserType(storedType);
        setIsLoading(false);
        return;
      }
      
      // If auth is still loading, wait for it
      if (auth.isLoading) {
        console.log("Auth is still loading, waiting...");
        return; // Don't set userType yet
      }
      
      // For non-authenticated users
      if (!auth.isAuthenticated) {
        // In development mode, default to a specific type for testing
        if (process.env.NODE_ENV === 'development') {
          console.log("Development mode: Using default user type 'gold' for testing");
          setUserType("gold");
          sessionStorage.setItem("userType", "gold");
        } else {
          // In production, don't set a default - the app should redirect to login
          console.log("Not authenticated, no default user type set");
        }
        setIsLoading(false);
        return;
      }

      // For authenticated users, check Cognito groups
      const groups = auth.user?.profile?.["cognito:groups"] || [];
      console.log("User groups from auth:", groups);

      // Look for specific group types
      if (groups.includes("Silver") || groups.includes("silver")) {
        console.log("User is in silver group");
        setUserType("silver");
        sessionStorage.setItem("userType", "silver");
      } else if (groups.includes("Gold") || groups.includes("gold")) {
        console.log("User is in gold group");
        setUserType("gold");
        sessionStorage.setItem("userType", "gold");
      } else if (groups.includes("Trial") || groups.includes("trial")) {
        console.log("User is in trial group");
        setUserType("trial");
        sessionStorage.setItem("userType", "trial");
      } else if (auth.user) {
        // User is authenticated but has no recognized group
        console.log("User authenticated but no recognized group, defaulting to 'trial'");
        setUserType("trial");
        sessionStorage.setItem("userType", "trial");
      }
      
      setIsLoading(false);
    } catch (error) {
      console.error("Error in useUserType hook:", error);
      setIsLoading(false);
      
      // Don't set a default type on error in production
      if (process.env.NODE_ENV === 'development') {
        console.log("Error in development mode - using fallback user type");
        setUserType("gold");
        sessionStorage.setItem("userType", "gold");
      }
    }
  }, [auth.isAuthenticated, auth.isLoading, auth.user]);

  // Return both the userType and loading state
  return { userType, isUserTypeLoading: isLoading };
};
